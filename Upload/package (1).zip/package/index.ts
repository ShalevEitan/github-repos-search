import { Alert, AlertLevel } from './alert';
import { AlertOptions } from './AlertOptions';
import * as TrelloNodeAPI from 'trello-node-api';
import {
    AlerterConfig,
    EmailConfig,
    EmailSubscriber,
    JiraConfig,
    TrelloConfig,
} from './alerterConfig';

import * as nodemailer from 'nodemailer';

import * as JiraClient from 'jira-client';

export class Alerter {
    constructor(private readonly config: AlerterConfig) {}

    public async alert(alert: Alert, options: AlertOptions) {
        return await Promise.allSettled([
            options.sendEmail
                ? this.sendAlertEmail(alert, this.config.emailConfig)
                : null,
            options.createJiraTicket
                ? this.createJiraIssue(alert, this.config.jiraConfig)
                : null,
            options.createTrelloTicket
                ? this.createTrelloTicket(alert, this.config.trelloConfig)
                : null,
        ]);
    }

    /**
     * 1.Produces a call to TRELLO.
     * 2.Creates a ticket according to the related alert.
     * @param alert - The alert object (contain the relevant info of the alert).
     * @param trelloConfig - The required configuration to trello.
     * @returns The response of the creation of the ticket.
     *          in case the trelloConfig is undefuned -> null .
     */
    private createTrelloTicket(
        alert: Alert,
        trelloConfig: TrelloConfig | undefined,
    ) {
        if (trelloConfig === undefined) {
            return null;
        }

        const trello = new TrelloNodeAPI();
        trello.setApiKey(trelloConfig.apiKey);
        trello.setOauthToken(trelloConfig.access_token);

        const data = {
            name: createSubject(alert),
            desc: createMessage(alert),

            pos: 'top',
            idList: trelloConfig?.idList, //REQUIRED ..in order to know the 'idList'-
            // click on random ticket in the list you need, then click Share then
            // click Export to JSON, there you will get the idList.
            idLabels: alert.tags
                .map((label: string) => trelloConfig.tagsMapping[label] || null)
                .filter(Boolean),
            due: null,
            dueComplete: false,
            urlSource: 'https://api.trello.com/1/', //trelloConfig?.url,
            fileSource: 'file',

            keepFromSource:
                'attachments,checklists,comments,due,labels,members,stickers',
        };

        return trello.card
            .create(data)
            .then(function (response: any) {
                return response;
                //console.log("response ", response);
            })
            .catch(function (error: any) {
                throw new Error(
                    'Trello ticket not created: ' + JSON.stringify(error),
                );
            });
    }

    /**
     * 1.Produces a call to JIRA.
     * 2.Creates a ticket according to the related alert.
     * @param alert - The alert object (contain the relevant info of the alert).
     * @param jiraConfig -The required configuration to jira.
     */
    private async createJiraIssue(
        alert: Alert,
        jiraConfig: JiraConfig | undefined,
    ) {
        if (jiraConfig === undefined) {
            return;
        }
        const jira = new JiraClient({
            protocol: 'https',
            host: jiraConfig.host, //"balink.atlassian.net", ///rest/api/3/issue/",
            username: jiraConfig.username, //"eitans@balink.net",
            password: jiraConfig.password, // "22xDhcniOl3MtTNDQyT942E7",
            apiVersion: '3',
            strictSSL: true,
        });

        //FIND ANY ISSUE:
        // jira
        //   .findIssue("ALRT-136")
        //   .then(function (issue) {
        //     console.log("Status: " + issue.fields.status.name);
        //   })
        //   .catch(function (err) {
        //     console.error(err);
        //   });

        return await jira
            .addNewIssue({
                fields: {
                    project: {
                        key: jiraConfig.projectKey, // "ALRT",
                    },
                    summary: createSubject(alert),
                    description: {
                        version: 1,
                        type: 'doc',
                        content: [
                            {
                                type: 'paragraph',
                                content: [
                                    {
                                        type: 'text',
                                        text: createMessage(alert),
                                    },
                                ],
                            },
                        ],
                    },
                    labels: [alert.env, alert.region],
                    issuetype: {
                        name: 'Task',
                    },
                },
            })
            .then(function (response: any) {
                return response;
                //console.log("response ", response);
            })
            .catch(function (error: any) {
                throw new Error(
                    'Jira ticket not created: ' + JSON.stringify(error),
                );
            });
    }

    /**
     * 1.Produces a connection to the MAIL SERVICE.
     * 2.Sends an Email according to the related alert.
     * @param alert - The alert object (contain the relevant info of the alert).
     * @param mailConfig - The required configuration to the current mail service.
     */
    private async sendAlertEmail(alert: Alert, mailConfig?: EmailConfig) {
        //Step 1 - Produces a connection to the MAIL SERVICE.
        const transporter = nodemailer.createTransport({
            service: mailConfig?.credentials.service,
            auth: {
                user: mailConfig?.credentials.username,
                pass: mailConfig?.credentials.password,
            },
        });
        const emailList = this.createEmailList(
            alert.level,
            mailConfig?.subscribers || [],
        );

        //Step 2 - Prepares the content of the email
        const mailOptions = {
            from: mailConfig?.credentials.username,
            to: emailList,
            subject: createSubject(alert), //alert.subject,
            text: createMessage(alert),
        };
        //Step 3 - Sends an Email according to the related alert.
        return await transporter
            .sendMail(mailOptions)
            .then(function (response: any) {
                return response;
            })
            .catch((error) => {
                throw new Error('Email not sent' + JSON.stringify(error));
            });
    }

    /**
     * This utility function gives an array of the relevant mailing lists.
     * Whoever has an alert rank >= than the 'level' of the alert- will be
     * included in the array, so will receive an email.
     * @param level - The alert level.
     * @param emailCongig - The list of people, we will return from it only the
     *                      people who need to receive the email.
     * @returns
     */
    private createEmailList(
        level: AlertLevel,
        subscribers: EmailSubscriber[],
    ): string[] {
        //First -prepares the list of relevant emails according to the type of the given alert.
        return subscribers
            .filter((sub: EmailSubscriber) => sub.hasSubscribedTo <= level)
            .map((sub: EmailSubscriber) => sub.email);
    }
}

function createSubject(alert: Alert): string {
    return `[${
        AlertLevel[alert.level]
    } alert][${alert.date.toISOString()}] in ${alert.projectName} (Region: ${
        alert.region
    }) (Environment: ${alert.env}) - ${alert.subject}`;
}

function createMessage(alert: Alert) {
    return (
        '\n alert level: ' +
        AlertLevel[alert.level] +
        '\n description: ' +
        alert.description +
        '\n in env: ' +
        alert.env +
        '\n and in region:' +
        alert.region
    );
}

function createAlert(
    subject: string,
    description: string,
    level: AlertLevel,
    env: string,
    region: string,
) {
    //way of use in project:
    //1.
    const newalert: Alert = {
        projectName: 'ALERTER',
        date: new Date(),
        level: level,
        description: description,
        subject: subject,
        env: env,
        region: region,
    };

    //2.
    const newAlertOptions: AlertOptions = {
        sendEmail: true,
        createJiraTicket: true,
        createTrelloTicket: true,
    };

    //3.
    const alertConfig: AlerterConfig = {
        emailConfig: {
            credentials: {
                service: 'gmail',
                username: 'ybhsoimahaha3@gmail.com',
                password: 'es026792441ES',
            },

            subscribers: [
                {
                    email: 'eitans@balink.net', //"elied@balink.net",
                    hasSubscribedTo: AlertLevel.HIGH,
                },
                {
                    email: 'eitans1111@gmail.com', //"elied@balink.net",
                    hasSubscribedTo: AlertLevel.LOW,
                },
                // {
                //   email: "yonah@balink.net", //"elied@balink.net",
                //   hasSubscribedTo: AlertLevel.HIGH,
                // },
                // {
                //   email: "elied@balink.net",
                //   hasSubscribedTo: AlertLevel.CRITICAL,
                // },
            ],
        },
        jiraConfig: {
            host: 'balink.atlassian.net',
            username: 'eitans@balink.net',
            password: '22xDhcniOl3MtTNDQyT942E7',
            projectKey: 'ALRT',
        },
        trelloConfig: {
            apiKey: 'f8cf9b08c9cdd68aca118a3ace6bfa36',
            access_token:
                'f07ddc1fd5d59900f887d154cb8b44c699b294e9be532e427d007a9f3055f58d',
            idList: '61cae3028eaef630425fdfec',
            tagsMapping: {
                APAC: '61d2d73980e97b13375b1a46',
                UAT: '61d2dbdf3d5be45b09fa7556',
            },
        },
    };

    //4. send alert
    const alerter = new Alerter(alertConfig);
    alerter.alert(newalert, newAlertOptions);
}

//const alerter = new Alerter()
//use in code:
// createAlert(
//     '🚨<--ISSUE subject-->123promise!🚨' + new Date().toString(),
//     'HI! WE FOUND AN ISSUE: ',
//     AlertLevel.CRITICAL,
//     'DEV',
//     'APAC;',
// );
