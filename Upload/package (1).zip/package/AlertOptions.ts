export interface AlertOptions {
    sendEmail: boolean;
    createJiraTicket: boolean;
    createTrelloTicket: boolean;
}
